---
name: diagnose-react-rendering
description: "Diagnoses React rerenders or request waterfalls when an observed interaction is slow; requires profiler and boundary evidence rather than blanket memoization or speculative speed claims."
license: MIT
metadata:
  author: "Measured Studios"
  version: "0.19.0"
  plugin: "measured-stacks"
  invocation: "implicit"
  provenance: "original"
  risk_class: "read-only"
---

# React Rendering Performance Diagnosis

Read [measured rendering diagnosis](references/measurement.md) only when its checks apply to the task. Project-local copies include a project contract; compare it with current repository settings before relying on it.

## Workflow

1. Name the slow interaction, data scale, runtime/build mode, device/browser, and available traces. Separate observed cost from a suspected cause.
2. Trace request scheduling, server/client serialization, component state ownership, expensive derivation, effects, identity, and render frequency. Read only the reference matching the suspected cost.
3. Use existing profiler or benchmark evidence. If measurements are unavailable, propose a bounded reproducible measurement and label the diagnosis provisional.
4. Propose the smallest change supported by the cost model. Check whether an effect is unnecessary, whether requests can overlap safely, and whether stable identity/state placement avoids repeated work.
5. Return evidence, competing hypotheses, proposed intervention, and a matched before/after protocol. Do not modify files; return Not Needed when no relevant rendering or waterfall question exists.

## Boundaries

Do not add memoization everywhere, alter cache/auth semantics, install profiling packages, or claim improvement from code inspection alone. Account for development instrumentation when interpreting timing.

## Evidence and output

Report the authorized scope, applicable settings, observed evidence, result, missing evidence, and next bounded check. Use Not Needed when no applicable authorized work exists and Blocked when a required precondition is missing. Do not substitute required headings for semantic compliance or invent executed checks.

## Example

Synthetic example; not an observed client result.

Input: A click is slow, but there is no profiler trace.

Output: Capture that interaction under comparable conditions. Separate rendering time from requests before adding memoization or changing component boundaries.
