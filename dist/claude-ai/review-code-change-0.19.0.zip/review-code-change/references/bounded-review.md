# Bounded review

Use this protocol when the user requests repeated review of one identified
change. It does not turn a findings-only review into authority to edit, delegate,
post replies, push, or merge. The implementing owner handles authorized repairs
between review passes. Self-review is the default and is not independent review.

## Pin the packet

Record the outcome, acceptance conditions, repository and PR when supplied, exact
base and head revisions, intended diff scope, and existing authorization. Include
relevant staged, unstaged, and untracked work. A committed diff does not include
those changes. Identify relevant uncommitted file contents by path and SHA-256;
label each hash as index (staged), working-tree, or untracked content. When one
path has different staged and working-tree bytes, retain both. Record deletions,
file types, and modes separately; do not follow links outside the authorized scope.
Review the intended staged tree before commit and reconcile the resulting commit
with that reviewed tree before push. Do not collect unrelated files, credentials,
or private logs. A pasted diff supports only its stated scope.

Keep the snapshot stable during each pass. If files or the remote head change,
identify what the reviewer actually saw and reconcile before using the result.
Read affected callers, contracts, tests, configuration, and generated boundaries.
An unchanged line can carry the consequence of a changed assumption.

## Spend the review budget deliberately

- The default is three review rounds per maintenance invocation, including
  self-review and delegated attempts. A failed or unusable delegated attempt
  consumes one round; preflight discovery without launching does not. Record the
  round as started before beginning self-review or dispatching a reviewer. Retain
  the dispatch identifier when available, then record its outcome. An interrupted
  or uncertain dispatch remains consumed until its status is reconciled; do not
  launch a duplicate to replace missing output.
- Round one covers the full identified change. Later rounds cover the delta,
  open findings, and surrounding behavior affected by the repair.
- The owner records each accepted repair and its checks. Reviewers return
  findings only; they do not modify the code they are reviewing.
- Stop a review cycle when no actionable findings remain. This does not clear
  required tests, other approvals, or later findings from new evidence.
- Evaluate documentation, naming, and configuration findings by their effects.
  Decline unsupported or out-of-scope suggestions with evidence, not by category.
- A new revision, new comment, interruption, or resumed session does not reset
  the allowance. Carry used and remaining rounds in the continuation record.
- Stop earlier when the same material failure recurs without new evidence or a
  changed remedy. Record the violated rule, observed condition, required condition,
  and next evidence needed; another critique is not progress by itself.
- Extend only with explicit additional authority. Risk alone does not permit
  extra rounds. On exhaustion, retain open findings and unreviewed repairs;
  do not claim that a final repair passed review without another available round.

## Optional independent review

Only launch a separate reviewer when delegation is explicitly authorized and the
actual host, effective permissions, model configuration, data exposure, and absence
of paid fallback are verified. Use one read-only reviewer at a time. No nested
reviewers, edits, external replies, publication, or merge are permitted. Do not
substitute a proxy, API, model, or account if the approved route is unavailable.

Verify supported deadline and stop controls before dispatch. Bound reviewer runtime
by the remaining CI/review wait allowance (30 minutes by default). If the host
cannot bound the call or stop this task's reviewer, the lane is unavailable.
Charge elapsed time while that reviewer is pending, even during owner work; count
overlapping CI/reviewer intervals once, and retain start/end times. On timeout,
user cancellation, or an authority/billing failure, stop only the reviewer this
task owns and read back its status. Report unconfirmed shutdown as unresolved;
do not claim the worker stopped or launch a replacement. Do not cancel hosted CI
or another task's workers as a way to satisfy this budget.

Continue authorized owner work when this optional lane is unavailable and say so.
If the task requires independent review, its absence remains a blocker. A separate
model is not independent human approval and does not remove correlated blind spots.

Give an authorized reviewer the pinned artifact, requirements, and relevant
evidence. Keep the author's preferred verdict and prior critique out of the first
pass unless the task is specifically to assess that feedback. Record any shared
context or model configuration that limits independence. Isolation can reduce
anchoring; it cannot establish correctness or eliminate shared failure modes.

## Preserve findings and limits

Keep stable finding IDs, location and reviewed snapshot, the claim and conditions,
severity and finding state, disposition, evidence, repair revision, and verification.
Use the existing severity/state vocabulary. Track five distinct state dimensions so
uncertainty never collapses into a reassuring status:

| Dimension | Allowed values or content | Invariant |
| --- | --- | --- |
| Investigation coverage | `examined`, `skipped`, `blocked`, or `excluded` | A skipped, blocked, or excluded path never becomes clean or covered. |
| Claim assessment | `supported`, `cleared`, or `unresolved` | An inconclusive counter-evidence or validation check stays `unresolved` and surfaces as a gap. |
| Disposition | `accept`, `reject`, `defer`, `clarify`, or `already addressed` | Owner decision; tracked independently of severity and claim assessment. |
| Verification | Observed command or artifact, exact revision, and setup conditions | Distinct from proposed assertions, static predictions, and prior-revision receipts. |
| Completion | Stopping condition met, budget exhausted, or blocked | A review can finish cleanly while preserving unresolved questions and coverage limits. |

A rejected finding can reopen when new evidence changes its premise; preserve the
earlier decision and reason.

Keep three assurance boundaries explicit when reviewing or automating handoffs:

- **Structural lint vs. evidence verification:** Checking that a revision ID,
  artifact link, command status, or required field exists checks document structure;
  it does not verify that the cited evidence establishes the claim.
- **Historical memory as priority only:** Prior findings or prior clean passes can
  inform inspection order, but their original scope, revision, and age must travel
  with them (see `design-agent-memory`). A skipped check stays `skipped`; a
  previously observed finding remains historical until revalidated on the current
  revision.
- **Control layers:** Keep a written instruction, a preflight check, an action-time
  restriction, and a post-hoc audit distinct. None automatically supplies the
  guarantee of another.

Report reviewed revision or snapshot, self/independent review mode, actual reviewer
identity when known, rounds used/remaining, unresolved findings, and coverage
limits. Never invent a model identity. A model verdict is not human approval.
