---
name: plan-change
description: "Plans a change when asked for implementation steps, acceptance criteria, or a handoff-ready design; resolves interfaces and dependencies before execution without treating the plan as authorization. Load this skill first, before inspecting files, whenever the request matches."
license: MIT
metadata:
  author: "Measured Studios"
  version: "0.19.0"
  plugin: "measured-workflows"
  invocation: "implicit"
  provenance: "original"
  risk_class: "read-only"
---

# Implementation Planning

Create an executable plan that another engineer can follow without reopening material design decisions.

Read [specification synthesis](references/specification-synthesis.md) when multiple evidence sources must become one behavioral contract. Read [work packages](references/work-packages.md) when the plan needs independently reviewable units. Read [decision map](references/decision-map.md) when unresolved choices or multiple sessions control sequencing.

Read [document lifecycle](references/document-lifecycle.md) when a specification or README drives implementation, or before recovering unfinished document work, reconciling evidence, or preparing a handoff. Read [decision map](references/decision-map.md) as well when unresolved choices control the next slice. Report a failed or unavailable reference read rather than implying it was loaded.

Read [design review](references/design-review.md) when assessing a design document, RFC, or specification before implementation.

Read [dependency upgrades](references/dependency-upgrade.md) when planning a dependency, runtime, or framework version change.

## Workflow

1. Confirm the approved problem, desired outcome, scope, non-goals, and decision owner.
2. Read applicable repository instructions and inspect the current repository and relevant authorized evidence before naming files, interfaces, or commands. If the request points to evidence stored elsewhere, follow that pointer within your allowed access. A failed search of the working directory does not show the evidence is missing.
3. Describe the target behavior and every public interface, data contract, state transition, or compatibility promise that changes.
4. Name the existing module to extend and its ownership boundary. Break work into behaviorally complete vertical slices with exact locations and dependencies, not test or PR tranches.
5. Define tests by risk: unit, integration, contract, migration, end-to-end, property, and manual observation as applicable.
6. Specify rollout, monitoring, compatibility, rollback, and data-recovery behavior.
7. Add checkpoints where evidence must be reviewed before proceeding.
8. State stopping conditions for missing authority, unexpected scope, failing safety gates, or invalidated assumptions.

## Quality rules

- Resolve discoverable facts from the repository instead of delegating discovery to the implementer.
- Distinguish proposed changes from ratified decisions.
- Walk the slices in order and confirm that each slice's prerequisites exist by that point. Move any slice that depends on later work.
- Name uncertainty directly; do not hide it inside vague steps.
- Keep one short outcome-and-architecture brief: capability, observable completion, module owner, state transitions, invariants, smallest end-to-end slice, and failure checkpoints. Match its depth to the change.
- For unfamiliar designs, explain the state model, failure modes, and a rejected alternative so the user can challenge the design before implementation.
- Do not perform implementation, publication, deployment, or merge unless separately authorized.

## Output

Lead with the answer. Use the shortest format that retains the required evidence and limits; expand when requested or needed. The items below describe required content, not mandatory headings.

Return `Objective`, `Current evidence`, `Interfaces`, `Implementation steps`, `Test strategy`, `Rollout and rollback`, `Checkpoints`, `Risks`, and `Stopping conditions`.

## Example

Synthetic example; not an observed client result.

Input: Plan a change to `parse(text)` so empty input returns `[]` while existing exceptions remain unchanged. No repository files have been supplied.

Output: The requested contract is clear, but the implementation plan is blocked on repository evidence. The proposed interface is `parse("") -> []` with existing exceptions preserved. First locate the parser and current error fixtures, then plan the smallest change and tests for empty, valid, and invalid input. The checkpoint is a review of those files and acceptance cases; stop if existing callers require a different empty-input result. Changes, commands, rollout, and rollback remain unselected until the repository is inspected.
